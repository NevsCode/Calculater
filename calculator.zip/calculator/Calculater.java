
package calculator;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculater implements ActionListener {
    
    JFrame frame;
    JTextField textfield;
    JButton[] numberButtons = new JButton[10];
    JButton[] functionButtons = new JButton[9];
    
    JButton addbutton;
    JButton divbutton;
    JButton subbutton;
    JButton mulbutton;
    
    JButton decbutton;
    JButton equalbutton;
    JButton deletebutton;
    JButton clearbutton;
    JButton negButton;
    
    JPanel panel;
    double number1 = 0,number2 = 0, result = 0;
    char operator;
    
    Calculater()
    {
        
        addbutton = new JButton("+");
        divbutton = new JButton("/");
        subbutton= new JButton("-");
        mulbutton = new JButton("*");
        decbutton = new JButton(",");
        equalbutton= new JButton("=");
        deletebutton = new JButton("Delete");
        clearbutton = new JButton("Clear");
        negButton = new JButton("(-)");
       
        textfield = new JTextField();
        textfield.setBounds(50,25,300,50);
        textfield.setForeground(Color.black);
        textfield.setEditable(false);
        
        functionButtons[0] = addbutton;
        functionButtons[1] = divbutton ;
        functionButtons[2] = subbutton;
        functionButtons[3] = mulbutton ;
        functionButtons[4] = decbutton ;
        functionButtons[5] = equalbutton;
        functionButtons[6] = deletebutton;
        functionButtons[7] = clearbutton ;
        functionButtons[8] = negButton;
        
        deletebutton.setBounds(50, 430,100, 50);
        clearbutton.setBounds(150, 430,100, 50);
        negButton.setBounds(250, 430,100, 50);
        
        for(int i = 0; i < 9;i++)
        {
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFocusable(false);
        }
        
        for(int i =0; i < 10;i++)
        {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFocusable(false);
            numberButtons[i].addActionListener(this);
             
        }
        
        panel = new JPanel();
        panel.setBounds(50, 100,300 ,300);
        panel.setForeground(Color.red);
        
        panel.setLayout(new GridLayout(4,4,8,8));
        
        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addbutton);
        
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(divbutton);
        
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(subbutton);
        
        panel.add(mulbutton);
        panel.add(numberButtons[0]);
        panel.add(decbutton);
        panel.add(equalbutton);
        
        frame = new JFrame("Calculator");
        frame.setSize(450, 550);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.black);
        frame.add(textfield);
        frame.add(panel);
        frame.add(deletebutton);
        frame.add(clearbutton);
        frame.add(negButton);
        
        frame.setVisible(true);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        for(int i =0; i < 10;i++)
        {
            if(e.getSource() ==  numberButtons[i] )
            {
                textfield.setText(textfield.getText().concat(String.valueOf(i)));
            }
           
        }
        if(e.getSource() == decbutton )
        {
           textfield.setText(textfield.getText().concat((".")));
            
        }
        
        if(e.getSource() == addbutton )
        {
           number1 = Double.parseDouble(textfield.getText());
           operator = '+';
           textfield.setText("");
            
        }
         if(e.getSource() == subbutton )
        {
           number1 = Double.parseDouble(textfield.getText());
           operator ='-';
           textfield.setText(" ");
            
        }
         if(e.getSource() == divbutton )
        {
           number1 = Double.parseDouble(textfield.getText());
           operator ='/';
           textfield.setText("");
            
        }
         if(e.getSource() == negButton )
        {
          
            textfield.setText(textfield.getText().concat(("-")));
            
        }
        if(e.getSource() == mulbutton )
        {
           number1 = Double.parseDouble(textfield.getText());
           operator ='*';
           textfield.setText("");
            
        } 
         
         if(e.getSource() == equalbutton )
        {
           number2 = Double.parseDouble(textfield.getText());
          
            switch(operator)
            {
                case'+':
                    result = number1 + number2;
                    break;
                case'*':
                    result = number1 * number2;
                    break;
                case'/':
                    result = number1 / number2;
                    break;
                case'-':
                    result = number1 - number2;
                    break;
               
            }
            textfield.setText(String.valueOf(result));
            number1 = result;
           
        }
        if(e.getSource() == clearbutton )
        {
            textfield.setText("");
        } 
        
        if(e.getSource() == deletebutton  )
        {
            String delete = textfield.getText();
            textfield.setText("");
            for(int i = 0;i < delete.length()-1;i++)
            {
                textfield.setText(textfield.getText() + delete.charAt(i));
            }
        }
       
    }

    
}
